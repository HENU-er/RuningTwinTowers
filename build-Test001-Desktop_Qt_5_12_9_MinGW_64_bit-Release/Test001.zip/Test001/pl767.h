#ifndef PL767_H
#define PL767_H

#include <QGraphicsPixmapItem>

class pl767 : public QGraphicsPixmapItem
{
public:
    pl767(QGraphicsPixmapItem *parent = nullptr);
    double movespeed;
    int health;
};

#endif // PL767_H
