#ifndef WIDGET_H
#define WIDGET_H
#include "car.h"
#include "pl767.h"
#include "tower1.h"
#include "supply.h"
#include "bulletblue.h"
#include <QTimer>
#include <QWidget>
#include <QGraphicsItem>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QKeyEvent>
#include <QList>
#include <QPoint>
#include <QDebug>
#include <QRect>
#include <QToolButton>
#include <QKeyEvent>
#include <QList>
#include <QProgressBar>
#include <QMediaPlayer>
#include <QLabel>
QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    QGraphicsView GameView;
    QGraphicsScene StartScene;
    QGraphicsScene ClassicGameScene;
    QGraphicsScene MultiplayerScene;

//设置背景
    QGraphicsPixmapItem StartBackGround1;
    QGraphicsPixmapItem StartBackGround2;
    QGraphicsPixmapItem ClassicGameBackGround1;
    QGraphicsPixmapItem ClassicGameBackGround2;
    QGraphicsPixmapItem MultiplayerBackGround1;
    QGraphicsPixmapItem MultiplayerBackGround2;
//飞机，车击毁动画
    QGraphicsPixmapItem Plane1Dead;
    QGraphicsPixmapItem Plane2Dead;
    QGraphicsPixmapItem CarDead;



//    QGraphicsPixmapItem StartButton;
//    QGraphicsPixmapItem ExitButton;
    int ClassicGameTowerType;
    int Gravity;
    car mcar;
    pl767 plane;
    pl767 plane1;
    pl767 plane2;
    pl767 planestep3;
    Supply supply;
    Tower1 Twins;
    Tower1 StepTwoBoss;
    Tower1 StepThreeBoss;
    car car1;
    int StepThreeEndLabelMoveSpeed;
    int supplyNum;
    int currentplane1;
    int currentplane2;
    int plane1type;
    int plane2type;
    int currentcar;
    int ClassicGameScore;
    int ClassicGameStepNum;
    int addplanecheck;
    int f16firecheck;
    int ClassicGameStepThreeFriendPlaneMoveCheck;
    int ClassicGameStepTwoPlayerTypeChangeCheck;
    int BossMoveCheck1;
    int BossMoveCheck2;
    int BossDeadCheck;
    int BossFireCheck;
    double ClassicGameStepThreeFriendPlaneMoveCheck2;
    //加分器
    QLabel* ClassicGameScorePrint;
    QLabel* supplyPrintLabel;
    QLabel* ClassicGameStepThreeEnd;
    QTimer* SurviveTimer;
    QProgressBar* ClassicGameTowerHealthBar;
    QMediaPlayer ClassicGameAudio1;
    QMediaPlayer ClassicGameAudio2;
    QMediaPlayer ClassicGameAudio3;
    QMediaPlayer GameButtonClickedAudio;
//经典游戏模式背景移动
    QTimer* StartTimer;
    QTimer* ClassicGameBackgroundTimer;
    QTimer* ClassicGamePlane_CarMoveTimer;
    QTimer* ClassicGamePlane1DeadTimer;
    QTimer* ClassicGamePlane2DeadTimer;
    QTimer* ClassicGameCarDeadTimer;
    QTimer* ClassicGameStepTwoPlayerTypeChangeTimer;
    QTimer* ClassicGamePlaneShootTimer;
    QTimer* BulletMoveTimer;
    QTimer* AddPlaneTimer;
    QTimer* BgmTimer;
    QTimer* BossMoveTimer;
    QTimer* BossMoveTimer2;
    QTimer* MultiplayerTimer;
    QTimer* StepThreeEndLabelTimer;

    QToolButton* StartGameButton;
    QToolButton* Exit;
    QToolButton* ClassicGame;
    QToolButton* Multiplayer;
    QToolButton* supplyPrintToolButton;
    QToolButton* Back;
    QToolButton* ClassicGameReloadButton;
    QToolButton* ClassicGameEndButton;
    QToolButton* StopButton;
    QToolButton* GameOption;
    int StopButtonIsClicked;
    void StopButtonClicked();
    void GameEndLabelMove();
    QPoint Plane1DeadPoint;
    QPoint Plane2DeadPoint;
    QPoint CarDeadPoint;
    int SceneNum;

    void keyPressEvent(QKeyEvent *event);
    void keyReleaseEvent(QKeyEvent *event);
//    void mousePressEvent(QMouseEvent *event);

    Widget(QWidget *parent = nullptr);
    ~Widget();
    QList<int> KeyList;
    QList<int> KeyList2;
    QList<BulletBlue*> BulletList;
    QList<BulletBlue*> BulletList2;
public slots:
    void StartBackgroundMove();
    void StartCarMove();
    void StartPlaneMove();
    void StartGameButtonClicked();
    void ExitClicked();
    void BackClicked();
    void GameOptionClicked();
    void ClassicGameClicked();
    void ClassicGameBackgroundMove();
    void ClassicGamePlane_CarMove();
    void ClassicGamePlayerMove();
    void ClassicGamePlane_CarMoveSpeedChange();
    void ClassicGamePlayerHealthCheck();
    void ClassicGameStepTwo();
    void ClassicGameReloadButtonClicked();
    void ClassicGameEndButtonClicked();
    void ClassicGameScoreUpdate();
    void ClassicGameStep3AddPlane();
    void ClassicGameStepThree();
    void ClassicGameStepTwoPlayerTypeChange();
    void StepTowBossMove();
    void StepThreeBossMove();
    void StepTwoBossDead();
    void StepThreeBossDead();
    void BulletShoot();
//死亡动画
    void ClassicGamePlane1Dead();
    void ClassicGamePlane2Dead();
    void ClassicGameCarDead();

    void MultiplayerClicked();

private:
    Ui::Widget *ui;
};
#endif // WIDGET_H
