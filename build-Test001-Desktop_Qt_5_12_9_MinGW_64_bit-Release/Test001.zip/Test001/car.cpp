#include "car.h"

car::car(QGraphicsPixmapItem *parent) : QGraphicsPixmapItem(parent)
{
    this->setPixmap(QPixmap(":/images/car.png"));
    movespeed = 2;
    health = 40;
}
