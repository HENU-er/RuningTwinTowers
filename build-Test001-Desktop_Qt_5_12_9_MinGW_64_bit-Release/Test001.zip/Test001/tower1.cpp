#include "tower1.h"

Tower1::Tower1(QGraphicsPixmapItem *parent) : QGraphicsPixmapItem(parent)
{
    this->setPixmap(QPixmap(":/images/TwinTowers.jpg"));

    movespeed = 4;
    jumpspeed = 10;
    currentspeedup = 0;
    health = 100;
    shootspeed = 600;
    StepThreeBossMoveSpeed = 0.4;

}
