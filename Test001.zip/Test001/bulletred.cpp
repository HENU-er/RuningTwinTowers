#include "bulletred.h"

BulletRed::BulletRed(QGraphicsPixmapItem *parent) : QGraphicsPixmapItem(parent)
{

}
