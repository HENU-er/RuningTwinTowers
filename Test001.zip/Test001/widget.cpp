#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    this->setWindowTitle("RunningTowers");
    this->setFixedSize(1152,630);

    SceneNum = 0;
    Gravity = 10;
    GameView.setSceneRect(QRect(0,0,1152,630));
    GameView.setParent(this);
    StartScene.setSceneRect(QRect(0,0,1152,630));
//设置开始背景图片
    StartBackGround1.setPixmap(QPixmap(":/images/start.jpg"));
    StartBackGround2.setPixmap(QPixmap(":/images/start.jpg"));
//设置开始界面场景
    StartScene.addItem(&StartBackGround2);
    StartScene.addItem(&StartBackGround1);
//设置背景图的位置
    StartBackGround1.setPos(0,0);
    StartBackGround2.setPos(1152,0);
//设置点击按钮的播放音效
    GameButtonClickedAudio.setParent(this);
    GameButtonClickedAudio.setMedia(QUrl("qrc:/music/opendoor.mp3"));

//    ExitButton.setPixmap(QPixmap(":/images/ExitButto.jpg"));
//    StartButton.setPixmap(QPixmap(":/images/StartButton.jpg"));
//    StartScene.addItem(&StartButton);
//    StartScene.addItem(&ExitButton);

//设置控制开始背景刷新的计算器
    StartTimer = new QTimer(this);
    StartTimer->start(10);
//开始界面添加载具
    StartScene.addItem(&mcar);
    StartScene.addItem(&plane);
//设置开始界面的载具位置
    mcar.setPos(500,580);
    plane.setPos(700,200);
    plane.setScale(0.5);
    mcar.setScale(0.5);

//    StartButton.setPos(452,200);
//    ExitButton.setPos(457,300);

//设置开始界面的按钮
    StartGameButton = new QToolButton();
    Exit = new QToolButton();
    ClassicGame = new QToolButton();
    Multiplayer = new QToolButton();
    Back = new QToolButton();
    GameOption = new QToolButton();
//设置按钮的图片文字信息
    Back->setIcon(QIcon(":/images/Back.jpg"));
    ClassicGame->setIcon(QIcon(":/images/ClassicGame.jpg"));
    Multiplayer->setIcon(QIcon(":/images/Multiplayer.jpg"));
    Exit->setIcon(QIcon(":/images/ExitButto.jpg"));
    StartGameButton->setIcon(QIcon(":/images/StartButton.jpg"));
    GameOption->setIcon(QIcon(":/images/GameOptionButton.jpg"));
//设置开始场景添加按钮
    StartScene.addWidget(Back);
    StartScene.addWidget(ClassicGame);
    StartScene.addWidget(Multiplayer);
    StartScene.addWidget(Exit);
    StartScene.addWidget(StartGameButton);
    StartScene.addWidget(GameOption);
//设置按钮尺寸
    Exit->setIconSize(QSize(237,73));
    StartGameButton->setIconSize(QSize(248,63));
    Multiplayer->setIconSize(QSize(310,70));
    ClassicGame->setIconSize(QSize(292,75));
    Back->setIconSize(QSize(180,73));
    GameOption->setIconSize(QSize(300,80));
//设置按钮位置
    Exit->move(457,300);
    StartGameButton->move(452,200);
    ClassicGame->move(430,220);
    Multiplayer->move(421,250);
    Back->move(486,350);
    GameOption->move(426,250);
//设置按钮边框效果
    StartGameButton->setAutoRaise(true);
    Exit->setAutoRaise(true);
    Back->setAutoRaise(true);
    ClassicGame->setAutoRaise(true);
    Multiplayer->setAutoRaise(true);
    GameOption->setAutoRaise(true);

    GameOption->hide();
    ClassicGame->hide();
    Back->hide();
    Multiplayer->hide();

//设置开始界面的背景和载具移动
    connect(StartTimer,&QTimer::timeout,this,&Widget::StartBackgroundMove);
    connect(StartTimer,&QTimer::timeout,this,&Widget::StartCarMove);
    connect(StartTimer,&QTimer::timeout,this,&Widget::StartPlaneMove);

//设置开始界面的按钮被按效果
    connect(Exit,&QToolButton::clicked,this,&Widget::ExitClicked);
    connect(StartGameButton,&QToolButton::clicked,this,&Widget::StartGameButtonClicked);
    connect(Back,&QToolButton::clicked,this,&Widget::BackClicked);
    connect(ClassicGame,&QToolButton::clicked,this,&Widget::ClassicGameClicked);
    connect(Multiplayer,&QToolButton::clicked,this,&Widget::MultiplayerClicked);


    Twins.shootspeed = 600;
//设置初始的飞机状态
    currentcar = 0;
    currentplane1 = 0;
    currentplane2 = 0;
    ClassicGameStepPlaneMoveCheck = 0;
//设置经典模式的当前游戏阶段
    ClassicGameStepNum = 1;
//经典模式背景
    ClassicGameBackGround1.setPixmap(QPixmap(":/images/ClassicGameBackground.jpg"));
    ClassicGameBackGround2.setPixmap(QPixmap(":/images/ClassicGameBackground.jpg"));
//设置飞机汽车碰撞音效
    ClassicGameAudio1.setParent(this);
    ClassicGameAudio1.setMedia(QUrl("qrc:/music/view~.mp3"));
    ClassicGameAudio2.setParent(this);
    ClassicGameAudio2.setMedia(QUrl("qrc:/music/dongji~.mp3"));
    ClassicGameAudio3.setParent(this);
    ClassicGameAudio3.setMedia(QUrl("qrc:/music/mus.mp3"));
//设置音效音量
    ClassicGameAudio1.setVolume(20);
    ClassicGameAudio2.setVolume(20);
    ClassicGameAudio3.setVolume(20);
//设置经典模式的初始补给数量
    supplyNum = 30;
//设置经典模式的初始分数
    ClassicGameScore = 0;
//设置经典模式的分数打印
    ClassicGameScorePrint = new QLabel();
    ClassicGameScorePrint->setText("ur score: " + QString::number(ClassicGameScore));
    supplyPrintLabel = new QLabel();
    supplyPrintLabel->setText(QString::number(supplyNum));
//设置经典模式塔楼的类型
    ClassicGameTowerType = 1;
//设置经典模式的塔楼血量显示，血量条的尺寸范围位置方向
    ClassicGameTowerHealthBar = new QProgressBar;
    ClassicGameTowerHealthBar->setRange(0,100);
    ClassicGameTowerHealthBar->setValue(100);
    ClassicGameTowerHealthBar->setOrientation(Qt::Horizontal);
    ClassicGameTowerHealthBar->move(0,150);
//设置经典模式暂停键的状态
    StopButtonIsClicked = 0;
    StopButton = new QToolButton();
//设置经典模式游戏结束时的弹窗按钮
    ClassicGameReloadButton = new QToolButton();
    ClassicGameEndButton = new QToolButton();
    supplyPrintToolButton = new QToolButton();
//设置按钮图片
    ClassicGameReloadButton->setIcon(QIcon(":/images/again.png"));
    ClassicGameEndButton->setIcon(QIcon(":/images/gameover.png"));
    StopButton->setIcon(QIcon(":/images/pause_nor.png"));
    supplyPrintToolButton->setIcon(QIcon(":/images/bullet_supply.png"));
//设置按钮尺寸
    ClassicGameReloadButton->setIconSize(QSize(300,41));
    ClassicGameEndButton->setIconSize(QSize(300,41));
    StopButton->setIconSize(QSize(60,45));
    ClassicGameScorePrint->resize(1000,35);
//设置按钮的颜色和透明度和尺寸
    ClassicGameScorePrint->setStyleSheet("background-color: rgb(44, 86, 173, 0)");
    StopButton->setStyleSheet("background-color: rgb(44, 86, 173, 0)");
    supplyPrintLabel->resize(1000,35);
    supplyPrintLabel->setStyleSheet("background-color: rgb(44, 86, 173, 0)");
    supplyPrintToolButton->setStyleSheet("background-color: rgb(44, 86, 173, 0)");
    supplyPrintToolButton->setIconSize(QSize(29,44));
//设置分数打印的字体的大小
    QFont w;
    w.setPointSize(14);
    ClassicGameScorePrint->setFont(w);
    supplyPrintLabel->setFont(w);
//设置经典模式游戏结束时弹出按钮的位置及计分器和暂停按钮的位置
    ClassicGameReloadButton->move(426,310);
    ClassicGameEndButton->move(426,400);
    StopButton->move(5,50);
    ClassicGameScorePrint->move(100,50);
    supplyPrintLabel->move(70,150);
    supplyPrintToolButton->move(20,180);
//设置按钮是否显示
    ClassicGameReloadButton->hide();
    ClassicGameEndButton->hide();
    StopButton->show();
    ClassicGameScorePrint->show();
    supplyPrintLabel->show();
//设置按钮边框效果
    ClassicGameReloadButton->setAutoRaise(true);
    ClassicGameEndButton->setAutoRaise(true);
    StopButton->setAutoRaise(true);
//设置经典模式场景添加背景物体及按钮

    QFont w2;
    w2.setPointSize(40);

    ClassicGameStepThreeEnd = new QLabel();
    ClassicGameStepThreeEnd->setFont(w2);
    ClassicGameStepThreeEnd->resize(1000,300);
    ClassicGameStepThreeEnd->move(210,80);
    ClassicGameStepThreeEnd->hide();
    ClassicGameStepThreeEnd->setStyleSheet("background-color: rgb(44, 86, 173, 0)");
    ClassicGameStepThreeEnd->setText("Game Over");

    ClassicGameScene.addItem(&ClassicGameBackGround1);
    ClassicGameScene.addItem(&ClassicGameBackGround2);
    ClassicGameScene.addItem(&StepTwoBoss);
    ClassicGameScene.addItem(&StepThreeBoss);
    ClassicGameScene.addItem(&plane1);
    ClassicGameScene.addItem(&plane2);
    ClassicGameScene.addItem(&Twins);
    ClassicGameScene.addItem(&car1);
    ClassicGameScene.addItem(&supply);
    ClassicGameScene.addWidget(StopButton);
    ClassicGameScene.addItem(&planestep3);
    ClassicGameScene.addWidget(ClassicGameTowerHealthBar);
    ClassicGameScene.addWidget(ClassicGameReloadButton);
    ClassicGameScene.addWidget(ClassicGameEndButton);
    ClassicGameScene.addWidget(ClassicGameScorePrint);
    ClassicGameScene.addWidget(supplyPrintToolButton);
    ClassicGameScene.addWidget(supplyPrintLabel);
    ClassicGameScene.addWidget(ClassicGameStepThreeEnd);

    planestep3.hide();


    StepTwoBoss.setPixmap(QPixmap(":/images/Tower2.jpg"));
//设置经典模式各元素的初始位置
    supply.setPos(1500,250);
    car1.setPos(850,578);
    car1.setScale(0.5);
    Twins.setPos(300,320);
    Twins.setScale(0.5);
    plane1.setScale(0.5);
    plane1.setPos(1500,500);
    plane2.setScale(0.5);
    plane2.setPos(700,100);
    planestep3.setPos(20,280);
    planestep3.setScale(0.5);
    StepThreeBoss.setScale(0.55);
    StepThreeBoss.setPos(1200,150);
    StepTwoBoss.setScale(0.5);
    StepTwoBoss.setPos(1200,220);


    ClassicGameBackGround1.setPos(0,0);
    ClassicGameBackGround2.setPos(1158,0);

    ClassicGameBackgroundTimer = new QTimer(this);
    ClassicGamePlane_CarMoveTimer = new QTimer(this);
    SurviveTimer = new QTimer(this);
    ClassicGamePlane1DeadTimer = new QTimer(this);
    ClassicGamePlane2DeadTimer = new QTimer(this);
    ClassicGameCarDeadTimer = new QTimer(this);
    ClassicGameStepTwoPlayerPlaneChangeTimer = new QTimer(this);

    ClassicGamePlaneShootTimer = new QTimer(this);
    BulletMoveTimer = new QTimer(this);
    AddPlaneTimer = new QTimer(this);
    BgmTimer = new QTimer(this);
    BossMoveTimer = new QTimer(this);
    BossMoveTimer2 = new QTimer(this);

    connect(ClassicGameBackgroundTimer,&QTimer::timeout,this,&Widget::ClassicGameBackgroundMove);
    connect(ClassicGameBackgroundTimer,&QTimer::timeout,this,&Widget::ClassicGameTowersMove);
    connect(ClassicGameBackgroundTimer,&QTimer::timeout,this,&Widget::ClassicGamePlane_CarMove);
    connect(ClassicGamePlane_CarMoveTimer,&QTimer::timeout,this,&Widget::ClassicGamePlane_CarMoveSpeedChange);
    connect(ClassicGameBackgroundTimer,&QTimer::timeout,this,&Widget::ClassicGameTowerHealthCheck);
    connect(ClassicGameReloadButton,&QToolButton::clicked,this,&Widget::ClassicGameReloadButtonClicked);
    connect(ClassicGameEndButton,&QToolButton::clicked,this,&Widget::ClassicGameEndButtonClicked);
    connect(StopButton,&QToolButton::clicked,this,&Widget::StopButtonClicked);
    connect(SurviveTimer,&QTimer::timeout,this,&Widget::ClassicGameScoreUpdate);
    connect(ClassicGamePlane1DeadTimer,&QTimer::timeout,this,&Widget::ClassicGamePlane1Dead);
    connect(ClassicGamePlane2DeadTimer,&QTimer::timeout,this,&Widget::ClassicGamePlane2Dead);
    connect(ClassicGameCarDeadTimer,&QTimer::timeout,this,&Widget::ClassicGameCarDead);
    connect(ClassicGamePlaneShootTimer,&QTimer::timeout,this,&Widget::Widget::BulletShoot);

    connect(BulletMoveTimer,&QTimer::timeout,[this](){
        QRect Plane1Area = QRect(plane1.x(),plane1.y(),plane1.pixmap().width()/2,plane1.pixmap().height()/2);
        QRect Plane2Area = QRect(plane2.x(),plane2.y(),plane2.pixmap().width()/2,plane2.pixmap().height()/2);
        QRect CarArea = QRect(car1.x(),car1.y(),car1.pixmap().width()/2,car1.pixmap().height()/2);
        QRect StepTwoBossArea = QRect(StepTwoBoss.x(),StepTwoBoss.y(),StepTwoBoss.pixmap().width()/2,StepTwoBoss.pixmap().height()/2);
        QRect StepThreeBossArea = QRect(StepThreeBoss.x(),StepThreeBoss.y(),StepThreeBoss.pixmap().width()/2,StepThreeBoss.pixmap().height()/2);
        for(auto bullet : BulletList)
        {
            bullet->BulletBlueMove();
            if(bullet->x() > 1140)
            {
                BulletList.removeOne(bullet);
                ClassicGameScene.removeItem(bullet);
                delete bullet;
            }

            QPoint BulletPoint = QPoint(bullet->x() + bullet->pixmap().width()/2,bullet->y());
            if(Plane1Area.contains(BulletPoint) && bullet->x() <= 1130)
            {
                plane1.health-=20;
                BulletList.removeOne(bullet);
                ClassicGameScene.removeItem(bullet);
                if(plane1.health<=0)
                {
                    Plane1DeadPoint = QPoint(plane1.x(),plane1.y());
                    ClassicGamePlane1DeadTimer->start(500);
                    Plane1Dead.setPixmap(QPixmap(":/images/enemy2_down3.png"));
                    Plane1Dead.setPos(Plane1DeadPoint);
                    ClassicGameScene.addItem(&Plane1Dead);

                    ClassicGameScore += 3;
                    ClassicGameAudio1.play();

                    plane1.setX(1350);
                    plane1.health = 60;
                    if(plane1.y() + 40 > 420)
                    {
                        plane1.setY(plane2.y() - 380);
                    }
                    else
                    {
                        plane1.setY(plane2.y() + 40);
                    }
                    if(plane1type == 1 && ClassicGameStepNum >= 2)
                    {
                        plane1.setPixmap(QPixmap(":/images/f16.png"));
                        ++plane1type;
                        plane1.setScale(0.3);
                    }

                }
            }

            if(Plane2Area.contains(BulletPoint) && bullet->x() <= 1130)
            {
                plane2.health-=20;
                BulletList.removeOne(bullet);
                ClassicGameScene.removeItem(bullet);
                if(plane2.health<=0)
                {
                    Plane2DeadPoint = QPoint(plane2.x(),plane2.y());
                    ClassicGamePlane2DeadTimer->start(500);
                    Plane2Dead.setPixmap(QPixmap(":/images/enemy2_down3.png"));
                    Plane2Dead.setPos(Plane2DeadPoint);
                    ClassicGameScene.addItem(&Plane2Dead);

                    ClassicGameScore += 3;
                    ClassicGameAudio2.play();

                    plane2.setX(1350);
                    plane2.health = 60;
                    if(plane2.y() + 160 > 450)
                    {
                        plane2.setY(plane2.y() - 290);
                    }
                    else
                    {
                        plane2.setY(plane2.y() + 160);
                    }
                    if(plane2type == 1 && ClassicGameStepNum >= 2)
                    {
                        plane2.setPixmap(QPixmap(":/images/f16.png"));
                        ++plane2type;
                        plane2.setScale(0.3);
                    }

                }
            }
            if(CarArea.contains(BulletPoint) && bullet->x() <= 1130)
            {
                car1.health-=20;
                ClassicGameScene.removeItem(bullet);
                BulletList.removeOne(bullet);
                if(car1.health<=0)
                {
                    CarDeadPoint = QPoint(car1.x(),car1.y());
                    ClassicGameCarDeadTimer->start(500);
                    CarDead.setPixmap(QPixmap(":/images/enemy2_down3.png"));
                    CarDead.setPos(CarDeadPoint);
                    ClassicGameScene.addItem(&CarDead);

                    ClassicGameScore += 1;
                    ClassicGameAudio2.play();

                    car1.setX(1200);
                    car1.health = 40;
                }
            }
            if(StepTwoBossArea.contains(BulletPoint) && bullet->x() <= 1130)
            {
                ClassicGameScene.removeItem(bullet);
                BulletList.removeOne(bullet);
                StepTwoBoss.health -= 4;
                if(StepTwoBoss.health <= 0)
                {

                    StepTwoBossDead();

                }
            }
            if(StepThreeBossArea.contains(BulletPoint) && bullet->x() <= 1130)
            {
                ClassicGameScene.removeItem(bullet);
                BulletList.removeOne(bullet);
                StepThreeBoss.health -= 1;
                if(StepThreeBoss.health <= 0)
                {

                    StepThreeBossDead();

                }
            }
        }
        for(auto bullet : BulletList2)
        {
            bullet->BulletBlueMove();
            if(bullet->x() < 0 || bullet->y() < 0 || bullet->y() > 630)
            {
                BulletList2.removeOne(bullet);
                ClassicGameScene.removeItem(bullet);
                delete bullet;
            }
            QPoint BulletPoint = QPoint(bullet->x() + bullet->pixmap().width()/2,bullet->y());
            QRect PlayerArea = QRect(Twins.x(),Twins.y(),Twins.pixmap().width()/2,Twins.pixmap().height()/2);
            QRect FriendPlaneArea = QRect(planestep3.x(),planestep3.y(),planestep3.pixmap().width()/2,planestep3.pixmap().height()/2);

            if(PlayerArea.contains(BulletPoint) || FriendPlaneArea.contains(BulletPoint))
            {
                BulletList2.removeOne(bullet);
                ClassicGameScene.removeItem(bullet);
                delete bullet;
                Twins.health -= 5;
                ClassicGameTowerHealthBar->setValue(Twins.health);
            }

        }
    });

    connect(BgmTimer,&QTimer::timeout,[this](){
        ClassicGameAudio3.play();
    });
    connect(GameOption,&QToolButton::clicked,this,&Widget::GameOptionClicked);
    addplanecheck = 0;

    GameView.setScene(&StartScene);
    GameView.setParent(this);
    GameView.show();

    Twins.show();

}



void Widget::StartGameButtonClicked()
{
    qDebug() << "StartGameButtonClicked";
    GameButtonClickedAudio.play();

    StartGameButton->hide();
    Exit->hide();
    ClassicGame->show();
    Multiplayer->hide();
    Back->show();
}
void Widget::ExitClicked()
{
    qDebug() << "ExitClicked";
    GameButtonClickedAudio.play();
    delete ui;
}
void Widget::BackClicked()
{
    qDebug() << "BackClicked";
    GameButtonClickedAudio.play();
    GameOption->hide();
    ClassicGame->hide();
    Back->hide();
    Multiplayer->hide();
    StartGameButton->show();
    Exit->show();
}

void Widget::GameOptionClicked()
{
    qDebug() << "GameOptionClicked";
    GameButtonClickedAudio.play();
}
void Widget::StartBackgroundMove()
{
    StartBackGround1.moveBy(-1,0);
    StartBackGround2.moveBy(-1,0);
    if(StartBackGround1.x() <= - 1152)
    {
        StartBackGround1.setPos(0,0);
        StartBackGround2.setPos(1152,0);
    }
}
void Widget::StartCarMove()
{
    mcar.moveBy(-1 * mcar.movespeed,0);
    if(mcar.x() <= -200)
    {
        mcar.setX(1300);
    }
}
void Widget::StartPlaneMove()
{
    plane.moveBy(-1 * plane.movespeed,0);
    if(plane.x() <= -300)
    {
        plane.setX(1500);
    }
}
void Widget::ClassicGameClicked()
{
    qDebug() <<"GameMode:ClassicGame";
    KeyList.clear();
    KeyList2.clear();
    ClassicGameStepThreeEnd->hide();
    Twins.show();
    Twins.shootspeed = 600;
    Twins.movespeed = 4;
    BossMoveCheck1 = 0;
    BossMoveCheck2 = 0;
    ClassicGameStepPlaneMoveCheck = 0;
    GameButtonClickedAudio.play();
    GameView.setSceneRect(QRect(0,81,1152,630));
    ClassicGameScene.setSceneRect(QRect(0,0,1158,711));
    GameView.setScene(&ClassicGameScene);

    ClassicGameStepPlaneMoveCheck2 = 50;
    SceneNum = 1;
    ClassicGameAudio3.play();
    StartTimer->stop();
    BgmTimer->start(130000);
    ClassicGameBackgroundTimer->start(10);
    ClassicGamePlane_CarMoveTimer->start(1500);
    SurviveTimer->start(2000);
    plane1.movespeed = 2.3;
    plane2.movespeed = 2;
    car1.movespeed = 1.6;
    ClassicGameStepTwoPlayerPlaneChangeCheck = 0;
    plane1.health = 60;
    plane2.health = 60;
    plane1type = 1;
    plane2type = 1;
    Twins.setPixmap(QPixmap(":/images/TwinTowers.jpg"));
    Twins.setScale(0.5);

}

void Widget::MultiplayerClicked()
{
    qDebug() <<"GameMode:Multiplayer";
    GameButtonClickedAudio.play();
    GameView.setSceneRect(QRect(0,81,1152,630));
    ClassicGameScene.setSceneRect(QRect(0,0,1158,711));
    GameView.setScene(&MultiplayerScene);

    SceneNum = 2;

    StartTimer->stop();
}
void Widget::ClassicGameBackgroundMove()
{
    supply.moveBy(-supply.movespeed,0);
    ClassicGameBackGround1.moveBy(-1,0);
    ClassicGameBackGround2.moveBy(-1,0);
    if(ClassicGameBackGround1.x() <= -1158)
    {
        ClassicGameBackGround1.setX(0);
        ClassicGameBackGround2.setX(1158);
    }
    if(supply.x() < -200)
    {
        supply.setX(2000);
    }
    if(ClassicGameStepPlaneMoveCheck != 0)
    {
        ClassicGameStepPlaneMoveCheck2 += 0.5;
        if(ClassicGameStepPlaneMoveCheck == 1)
        {
            planestep3.moveBy(0,1);
            if(planestep3.y() >= 420)
            {
                ClassicGameStepPlaneMoveCheck = 2;
            }
        }
        if(ClassicGameStepPlaneMoveCheck == 2)
        {
            planestep3.moveBy(0,-1);
            if(planestep3.y() <= 150)
            {
                ClassicGameStepPlaneMoveCheck = 1;
            }
        }

        if(ClassicGameStepPlaneMoveCheck2 <= 50)
        {
            planestep3.moveBy(0.5,0);
        }
        if(ClassicGameStepPlaneMoveCheck2 > 50 && ClassicGameStepPlaneMoveCheck2 <= 100)
        {
            planestep3.moveBy(-0.5,0);
            if(ClassicGameStepPlaneMoveCheck2 >= 100)
            {
                ClassicGameStepPlaneMoveCheck2 = 0;
            }
        }
    }

}
void Widget::StopButtonClicked()
{
    qDebug() << "StopButtonClicked";
    GameButtonClickedAudio.play();
    if(StopButtonIsClicked == 0)
    {
        //监测暂停按钮状态是否被按
        StopButtonIsClicked = 1;
        //计时器暂停，停止刷新
        SurviveTimer->stop();
        ClassicGameBackgroundTimer->stop();
        ClassicGamePlane_CarMoveTimer->stop();
        ClassicGamePlaneShootTimer->stop();
        StopButton->setIcon(QIcon(":/images/resume_nor.png"));
    }
    else if(StopButtonIsClicked == 1)
    {
        StopButtonIsClicked = 0;
        //计算器开始计时
        SurviveTimer->start(2000);
        ClassicGameBackgroundTimer->start(10);
        ClassicGamePlane_CarMoveTimer->start(1500);
        if(ClassicGameTowerType >= 3)
        {
            ClassicGamePlaneShootTimer->start(Twins.shootspeed);
        }
        StopButton->setIcon(QIcon(":/images/pause_nor.png"));
    }

}
void Widget::ClassicGameScoreUpdate()
{
    ClassicGameScore += 1;
    ClassicGameScorePrint->setText("ur score: " + QString::number(ClassicGameScore));
}

void Widget::ClassicGameStep3AddPlane()
{
    ++addplanecheck;
    if(addplanecheck == 1)
    {
        planestep3.setPixmap(QPixmap(":/images/enemy3_down6.png"));
        connect(AddPlaneTimer,&QTimer::timeout,this,&Widget::ClassicGameStep3AddPlane);
        AddPlaneTimer->start(500);
    }
    if(addplanecheck == 2)
    {
        planestep3.setPixmap(QPixmap(":/images/plane767_2.png"));
    }
    if(addplanecheck == 3)
    {
        ClassicGameStepPlaneMoveCheck = 1;
        AddPlaneTimer->stop();
        addplanecheck = 0;
        disconnect(AddPlaneTimer,&QTimer::timeout,this,&Widget::ClassicGameStep3AddPlane);
    }


}

void Widget::BulletShoot()
{
    QPixmap bulletimage(":/images/bullet1.png");
    QPoint pos(Twins.x() + Twins.pixmap().width() / 2,Twins.y() + Twins.pixmap().height()/4 - bulletimage.height()/2);
    BulletBlue* bullet = new BulletBlue(pos,bulletimage,QPoint(1,0));
    ClassicGameScene.addItem(bullet);
    BulletList.append(bullet);

    if(StepTwoBoss.health > 0)
    {
        ++BossFireCheck;
        QPixmap bulletimage2(":/images/bullet2.png");

        if(BossFireCheck <= 10)
        {
            QPoint pos2_1(StepTwoBoss.x(),StepTwoBoss.y()+StepTwoBoss.pixmap().height()/4);
            QPoint pos2_2(StepTwoBoss.x(),StepTwoBoss.y()+StepTwoBoss.pixmap().height()/2);

            BulletBlue* bullet2_1 = new BulletBlue(pos2_1,bulletimage2,QPoint(-3,-1));
            BulletBlue* bullet2_2 = new BulletBlue(pos2_2,bulletimage2,QPoint(-3,1));
            BulletBlue* bullet2_3 = new BulletBlue(pos2_1,bulletimage2,QPoint(-1,0));
            BulletList2.append(bullet2_1);
            BulletList2.append(bullet2_2);
            BulletList2.append(bullet2_3);
            ClassicGameScene.addItem(bullet2_1);
            ClassicGameScene.addItem(bullet2_2);
            ClassicGameScene.addItem(bullet2_3);
        }
        else if(BossFireCheck > 15 && BossFireCheck <= 25)
        {
            QPoint pos2_1(StepTwoBoss.x(),StepTwoBoss.y()+StepTwoBoss.pixmap().height()/4);
            QPoint pos2_2(StepTwoBoss.x(),StepTwoBoss.y()+StepTwoBoss.pixmap().height()/2);
            BulletBlue* bullet2_1 = new BulletBlue(pos2_1,bulletimage2,QPoint(-2,0));
            BulletBlue* bullet2_2 = new BulletBlue(pos2_2,bulletimage2,QPoint(-2,0));
            BulletList2.append(bullet2_1);
            BulletList2.append(bullet2_2);
            ClassicGameScene.addItem(bullet2_1);
            ClassicGameScene.addItem(bullet2_2);
        }
        else if(BossFireCheck >= 30)
        {
            BossFireCheck = 0;
        }
    }
    if(ClassicGameStepNum == 3)
    {
        if(StepThreeBoss.health > 0)
        {
            ++BossFireCheck;
            QPixmap bulletimage2(":/images/bullet2.png");

            if(BossFireCheck <= 6)
            {
                QPoint pos3_1(StepThreeBoss.x(),StepThreeBoss.y()+StepThreeBoss.pixmap().height()/4);
                QPoint pos3_2(StepThreeBoss.x(),StepThreeBoss.y()+StepThreeBoss.pixmap().height()/2);
                QPoint pos3_3(StepThreeBoss.x(),StepThreeBoss.y()+StepThreeBoss.pixmap().height()/2+StepThreeBoss.pixmap().height()/4);
                BulletBlue* bullet3_1 = new BulletBlue(pos3_1,bulletimage2,QPoint(-1,0));
                BulletBlue* bullet3_2 = new BulletBlue(pos3_2,bulletimage2,QPoint(-2,0));
                BulletBlue* bullet3_3 = new BulletBlue(pos3_3,bulletimage2,QPoint(-1,0));
                BulletList2.append(bullet3_1);
                BulletList2.append(bullet3_2);
                BulletList2.append(bullet3_3);
                ClassicGameScene.addItem(bullet3_1);
                ClassicGameScene.addItem(bullet3_2);
                ClassicGameScene.addItem(bullet3_3);
            }
            else if(BossFireCheck > 8 && BossFireCheck <= 14)
            {
                QPoint pos3_1(StepThreeBoss.x(),StepThreeBoss.y()+StepThreeBoss.pixmap().height()/4);
                QPoint pos3_2(StepThreeBoss.x(),StepThreeBoss.y()+StepThreeBoss.pixmap().height()/2);
                BulletBlue* bullet3_1 = new BulletBlue(pos3_1,bulletimage2,QPoint(-2,0));
                BulletBlue* bullet3_2 = new BulletBlue(pos3_2,bulletimage2,QPoint(-2,0));
                BulletList2.append(bullet3_1);
                BulletList2.append(bullet3_2);
                ClassicGameScene.addItem(bullet3_1);
                ClassicGameScene.addItem(bullet3_2);
            }
            else if(BossFireCheck >= 16)
            {
                BossFireCheck = 0;
            }
            if(BossFireCheck % 3 == 0)
            {
                QPoint pos3_4(StepThreeBoss.x(),StepThreeBoss.y()+StepThreeBoss.pixmap().height()/4);
                BulletBlue* bullet3_4 = new BulletBlue(pos3_4,bulletimage2,QPoint(-2,1));
                BulletList2.append(bullet3_4);
                ClassicGameScene.addItem(bullet3_4);
            }
            if(BossFireCheck % 3 == 5)
            {
                QPoint pos3_5(StepThreeBoss.x(),StepThreeBoss.y()+StepThreeBoss.pixmap().height()/4);
                BulletBlue* bullet3_5 = new BulletBlue(pos3_5,bulletimage2,QPoint(-2,-1));
                BulletList2.append(bullet3_5);
                ClassicGameScene.addItem(bullet3_5);
            }

        }
        QPoint pos2(planestep3.x() + planestep3.pixmap().width() / 2,planestep3.y() + planestep3.pixmap().height()/4 - bulletimage.height()/2);
        BulletBlue* bullet2 = new BulletBlue(pos2,bulletimage,QPoint(1,0));
        ClassicGameScene.addItem(bullet2);
        BulletList.append(bullet2);
    }
}
void Widget::keyPressEvent(QKeyEvent *event)
{
    if(ClassicGameTowerType != 3)
    {
        switch(event->key())
        {
            case Qt::Key_W: if((Twins.y() >= 320 && ClassicGameTowerType == 1) || (Twins.y() >=530 && ClassicGameTowerType == 2)) Twins.currentspeedup = Twins.jumpspeed; break;
            case Qt::Key_S: Twins.setPixmap(QPixmap(":/images/Tower2.jpg")), Twins.moveBy(0,218), ClassicGameTowerType = 2, Twins.movespeed = 2; break;
            case Qt::Key_A: KeyList.append(event->key()); break;
            case Qt::Key_D: KeyList.append(event->key()); break;
            case Qt::Key_E: ClassicGameStepTwo(); break;
        }
    }
    else if(ClassicGameTowerType == 3)
    {
        switch(event->key())
        {
            case Qt::Key_W: KeyList2.append(event->key()); break;
            case Qt::Key_S: KeyList2.append(event->key());  break;
            case Qt::Key_A: KeyList2.append(event->key()); break;
            case Qt::Key_D: KeyList2.append(event->key()); break;
            case Qt::Key_E: ClassicGameStepThree(); break;
        }
    }
}
void Widget::keyReleaseEvent(QKeyEvent *event)
{
    if(ClassicGameTowerType != 3)
    {
        if(KeyList.contains(event->key()))
        {
            KeyList.removeOne(event->key());
        }
        if(event->key() == Qt::Key_S)
        {
            Twins.setPixmap(QPixmap(":/images/TwinTowers.jpg"));
            Twins.moveBy(0,-218);
            Twins.movespeed = 4;
            ClassicGameTowerType = 1;
        }
    }
    if(ClassicGameTowerType == 3)
    {
        if(KeyList2.contains(event->key()))
        {
            KeyList2.removeOne(event->key());
        }
    }
}
void Widget::ClassicGamePlane_CarMoveSpeedChange()
{
    plane1.movespeed += 0.03;
    plane2.movespeed += 0.03;
    car1.movespeed += 0.03;
}
void Widget::ClassicGameTowersMove()
{
    if(ClassicGameTowerType != 3)
    {
        for(int keyCode : KeyList)
        {
            switch(keyCode)
            {
                case Qt::Key_A: if(Twins.x() > 0) Twins.moveBy(-Twins.movespeed,0); break;
                case Qt::Key_D: if(Twins.x() + Twins.pixmap().width() / 2 < 1152) Twins.moveBy(Twins.movespeed,0); break;
            }
        }
        if(Twins.y() <= 330 && ClassicGameTowerType == 1)
        {
            Twins.currentspeedup -= 0.02 * 10;
            Twins.moveBy(0,-Twins.currentspeedup);
        }
        else if(Twins.y() <= 550 && ClassicGameTowerType == 2)
        {
            Twins.currentspeedup -= 0.02 * 10;
            Twins.moveBy(0,-Twins.currentspeedup);
        }
        if(Twins.y() >= 320 && ClassicGameTowerType == 1)
        {
            Twins.currentspeedup = 0;
            Twins.setY(320);
        }
        else if(Twins.y() >= 538 && ClassicGameTowerType == 2)
        {
            Twins.currentspeedup = 0;
            Twins.setY(538);
        }
    }
    if(ClassicGameTowerType == 3)
    {
        for(int keyCode : KeyList2)
        {
            switch(keyCode)
            {
                case Qt::Key_W: if(Twins.y() > 10) Twins.moveBy(0,-Twins.movespeed); break;
                case Qt::Key_S: if(Twins.y() < 550) Twins.moveBy(0,Twins.movespeed); break;
                case Qt::Key_A: if(Twins.x() > 0) Twins.moveBy(-Twins.movespeed,0); break;
                case Qt::Key_D: if(Twins.x() + Twins.pixmap().width() / 2 < 1152) Twins.moveBy(Twins.movespeed,0); break;
            }
        }

    }
}
void Widget::ClassicGamePlane_CarMove()
{
    plane1.moveBy(-plane1.movespeed,0);
    plane2.moveBy(-plane2.movespeed,0);
    car1.moveBy(-car1.movespeed,0);
    if(car1.x() <= -450)
    {
        car1.setX(1500);

    }
    if(plane1.x() <= -500)
    {
        plane1.setX(1500);
        if(ClassicGameTowerType == 3)
        {
            if(plane1.y() + 40 > 420)
            {
                plane1.setY(plane2.y() - 380);
            }
            else
            {
                plane1.setY(plane2.y() + 40);
            }
        }
        if(plane1type == 1 && ClassicGameStepNum >= 2)
        {
            plane1.setPixmap(QPixmap(":/images/f16.png"));
            plane1.setScale(0.3);
            ++plane1type;
        }
    }
    if(plane2.x() <= -400)
    {
        plane2.setX(1300);
        if(ClassicGameTowerType == 3)
        {
            if(plane2.y() + 160 > 450)
            {
                plane2.setY(plane2.y() - 290);
            }
            else
            {
                plane2.setY(plane2.y() + 160);
            }
        }
        if(plane2type == 1 && ClassicGameStepNum >= 2)
        {
            plane2.setPixmap(QPixmap(":/images/f16.png"));
            plane2.setScale(0.3);
            ++plane2type;
        }
    }
}
void Widget::ClassicGameStepTwo()
{
    KeyList.clear();
    if(ClassicGameStepNum != 1 || supplyNum < 20)
    {
        return;
    }
    ClassicGameAudio1.play();
    ClassicGameStepNum = 2;
    ClassicGameTowerType = 3;
    supplyNum -= 20;
    supplyPrintLabel->setText(QString::number(supplyNum));

    Twins.health = 100;
    Twins.movespeed = 2.5;
    BossDeadCheck = 0;
    StepTwoBoss.health = 100;
    BossFireCheck = 0;
    BossMoveCheck1 = 0;
    BossMoveCheck2 = 0;
    ClassicGamePlaneShootTimer->start(Twins.shootspeed);
    BulletMoveTimer->start(10);
    StepTwoBoss.show();
    ClassicGameStepTwoPlayerPlaneChange();
    StepTowBossMove();
}

void Widget::ClassicGameStepThree()
{
    qDebug() <<"StepThree";
    if(ClassicGameStepNum != 2 || supplyNum < 10 || StepTwoBoss.health > 0)
    {
        return;
    }
    ClassicGameAudio1.play();
    ClassicGameStepNum = 3;
    supplyNum -= 10;
    supplyPrintLabel->setText(QString::number(supplyNum));

    Twins.health = 100;
    Twins.movespeed = 2;
    Twins.shootspeed -= 80;
    StepThreeBoss.health = 100;
    StepThreeBoss.show();
    ClassicGameStep3AddPlane();
    ClassicGameStepPlaneMoveCheck2 = 50;
    BossFireCheck = 0;
    planestep3.show();
    BossMoveCheck1 = 0;
    BossMoveCheck2 = 0;
    StepThreeBossMove();
}

void Widget::ClassicGameStepTwoPlayerPlaneChange()
{

    ++ClassicGameStepTwoPlayerPlaneChangeCheck;
    if(ClassicGameStepTwoPlayerPlaneChangeCheck == 1)
    {
        qDebug() << "ClassicGameStepTwoPlayerPlaneChangeCheck ="<<ClassicGameStepTwoPlayerPlaneChangeCheck;
        ClassicGameStepTwoPlayerPlaneChangeTimer->start(500);
        Twins.setPixmap(QPixmap(":/images/enemy3_down6.png"));
        connect(ClassicGameStepTwoPlayerPlaneChangeTimer,&QTimer::timeout,this,&Widget::ClassicGameStepTwoPlayerPlaneChange);
    }
    if(ClassicGameStepTwoPlayerPlaneChangeCheck == 2)
    {
        qDebug() << "ClassicGameStepTwoPlayerPlaneChangeCheck ="<<ClassicGameStepTwoPlayerPlaneChangeCheck;
        Twins.setPixmap(QPixmap(":/images/plane767_2.png"));
        disconnect(ClassicGameStepTwoPlayerPlaneChangeTimer,&QTimer::timeout,this,&Widget::ClassicGameStepTwoPlayerPlaneChange);
        ClassicGameStepTwoPlayerPlaneChangeTimer->stop();
        ClassicGameStepTwoPlayerPlaneChangeCheck = 0;
    }
}

void Widget::StepTowBossMove()
{
    ++BossMoveCheck1;
    ++BossMoveCheck2;
    if(BossMoveCheck1 == 1)
    {
        BossMoveTimer->start(10);
        connect(BossMoveTimer,&QTimer::timeout,this,&Widget::StepTowBossMove);
    }
    if(StepTwoBoss.x() > 825)
    {
        StepTwoBoss.moveBy(-1,0);
    }
    if(BossMoveCheck1 <= 101 && BossMoveCheck1 >= 2)
    {
        StepTwoBoss.moveBy(-0.4,0);
    }
    if(BossMoveCheck1 <= 201 && BossMoveCheck1 >= 102)
    {
        StepTwoBoss.moveBy(0.4,0);
        if(BossMoveCheck1 == 201)
        {
            BossMoveCheck1 = 1;
        }
    }
    if(BossMoveCheck2 <= 400 && BossMoveCheck2 >= 1)
    {
        StepTwoBoss.moveBy(0,0.6);
    }
    if(BossMoveCheck2 <= 800 && BossMoveCheck2 >= 401)
    {
        StepTwoBoss.moveBy(0,-0.6);
        if(BossMoveCheck2 == 800)
        {
            BossMoveCheck2 = 0;
        }
    }
    if(StepTwoBoss.health == 0 || Twins.health == 0)
    {
        BossMoveCheck1 = 0;
        BossMoveCheck2 = 0;

        disconnect(BossMoveTimer,&QTimer::timeout,this,&Widget::StepTowBossMove);

    }
}

void Widget::StepThreeBossMove()
{
    ++BossMoveCheck1;
    ++BossMoveCheck2;

    if(BossMoveCheck1 == 1)
    {
        BossMoveTimer2->start(10);
        connect(BossMoveTimer2,&QTimer::timeout,this,&Widget::StepThreeBossMove);
    }
    if(StepThreeBoss.x() > 925)
    {
        StepThreeBoss.moveBy(-1,0);
    }
    if(BossMoveCheck1 <= 101 && BossMoveCheck1 >= 2)
    {
        StepThreeBoss.moveBy(-0.5,0);
    }
    if(BossMoveCheck1 <= 201 && BossMoveCheck1 >= 102)
    {
        StepThreeBoss.moveBy(0.4,0);
        if(BossMoveCheck1 == 201)
        {
            BossMoveCheck1 = 1;
        }
    }
    if(BossMoveCheck2 <= 400 && BossMoveCheck2 >= 1)
    {
        StepThreeBoss.moveBy(0,StepThreeBoss.StepThreeBossMoveSpeed);
    }
    if(BossMoveCheck2 <= 800 && BossMoveCheck2 >= 401)
    {
        StepThreeBoss.moveBy(0,-StepThreeBoss.StepThreeBossMoveSpeed);
        if(BossMoveCheck2 == 800)
        {
            BossMoveCheck2 = 0;
        }
    }
    if(StepThreeBoss.health == 0 || Twins.health == 0)
    {
        BossMoveCheck1 = 0;
        BossMoveCheck2 = 0;

        disconnect(BossMoveTimer2,&QTimer::timeout,this,&Widget::StepThreeBossMove);
    }
}

void Widget::StepTwoBossDead()
{
    ++BossDeadCheck;
    if(BossDeadCheck == 1)
    {
        StepTwoBoss.setPixmap(QPixmap(":/images/enemy2_down3.png"));
        BossMoveTimer->start(500);
        ClassicGameScore += 15;
        ClassicGameAudio2.play();
        connect(BossMoveTimer,&QTimer::timeout,this,&Widget::StepTwoBossDead);
    }
    if(BossDeadCheck == 2)
    {
        StepTwoBoss.setPixmap(QPixmap(":/images/enemy3_down6.png"));
    }
    if(BossDeadCheck == 3)
    {
        StepTwoBoss.hide();
        BossMoveTimer->stop();
        BossDeadCheck = 0;
        disconnect(BossMoveTimer,&QTimer::timeout,this,&Widget::StepTwoBossDead);
    }
}

void Widget::StepThreeBossDead()
{
    ++BossDeadCheck;
    if(BossDeadCheck == 1)
    {
        ClassicGameAudio2.play();
        ClassicGameScore += 22;
        StepThreeBoss.setPixmap(QPixmap(":/images/enemy2_down3.png"));
        BossMoveTimer->start(500);
        connect(BossMoveTimer,&QTimer::timeout,this,&Widget::StepThreeBossDead);
    }
    if(BossDeadCheck == 2)
    {
        StepThreeBoss.setPixmap(QPixmap(":/images/enemy3_down6.png"));
    }
    if(BossDeadCheck == 3)
    {
        StepThreeBoss.hide();
        BossMoveTimer->stop();
        BossDeadCheck = 0;
        disconnect(BossMoveTimer,&QTimer::timeout,this,&Widget::StepThreeBossDead);
    }
}

void Widget::ClassicGamePlane1Dead()
{
    qDebug()<<"DeadTimer->timeId = "<<ClassicGamePlane1DeadTimer->timerId();

    ++currentplane1;
    //检测当前飞机爆炸贴图
    if(currentplane1 == 1)
    {
        Plane1Dead.setPixmap(QPixmap(":/images/enemy2_down4.png"));
    }
    if(currentplane1 == 2)
    {
        currentplane1 = 0;
        ClassicGameScene.removeItem(&Plane1Dead);
        ClassicGamePlane1DeadTimer->stop();
    }
}
void Widget::ClassicGamePlane2Dead()
{
    qDebug()<<"ClassicGamePlane2DeadTimer->timeId = "<<ClassicGamePlane2DeadTimer->timerId();

    ++currentplane2;
    if(currentplane2 == 1)
    {
        Plane2Dead.setPixmap(QPixmap(":/images/enemy2_down4.png"));
    }
    if(currentplane2 == 2)
    {
        currentplane2 = 0;
        ClassicGameScene.removeItem(&Plane2Dead);
        ClassicGamePlane2DeadTimer->stop();
    }
}
void Widget::ClassicGameCarDead()
{
    qDebug()<<"DeadTimer->timeId = "<<ClassicGameCarDeadTimer->timerId();

    ++currentcar;
    if(currentcar == 1)
    {
        CarDead.setPixmap(QPixmap(":/images/enemy2_down4.png"));
    }
    if(currentcar == 2)
    {
        currentcar = 0;
        ClassicGameScene.removeItem(&CarDead);
        ClassicGameCarDeadTimer->stop();
    }
}
void Widget::ClassicGameTowerHealthCheck()
{
    if(ClassicGameTowerType != 3)
    {
        QRect BuildingArea = QRect(Twins.x(),Twins.y(),Twins.pixmap().width() / 2,Twins.pixmap().height() / 2);
        QPoint Plane1Area = QPoint(plane1.x() + plane1.pixmap().width()/8,plane1.y() + plane1.pixmap().height()/4);
        QPoint Plane2Area = QPoint(plane2.x() + plane2.pixmap().width()/8,plane2.y() + plane2.pixmap().height()/4);
        QPoint CarArea = QPoint(car1.x(),car1.y());
        QPoint SupplyArea = QPoint(supply.x(),supply.y());

        if(BuildingArea.contains(SupplyArea) && ClassicGameTowerType != 3)
        {
            if(Twins.health + 15 <= 100)
            {
                Twins.health += 15;
                ClassicGameTowerHealthBar->setValue(Twins.health);
            }
            supply.setX(2000);
            ++supplyNum;
            supplyPrintLabel->setText(QString::number(supplyNum));
        }
        if(BuildingArea.contains(Plane1Area) && ClassicGameTowerType == 1)
        {
            Plane1DeadPoint = QPoint(plane1.x(),plane1.y());
            ClassicGamePlane1DeadTimer->start(500);
            Plane1Dead.setPixmap(QPixmap(":/images/enemy2_down3.png"));
            Plane1Dead.setPos(Plane1DeadPoint);
            ClassicGameScene.addItem(&Plane1Dead);

            ClassicGameAudio1.play();
            Twins.health -= 50;
            plane1.setX(1850);
            ClassicGameTowerHealthBar->setValue(Twins.health);
        }
        if(BuildingArea.contains(Plane2Area) && ClassicGameTowerType == 1)
        {
            Plane2DeadPoint = QPoint(plane2.x(),plane2.y());
            ClassicGamePlane2DeadTimer->start(500);
            Plane2Dead.setPixmap(QPixmap(":/images/enemy2_down3.png"));
            Plane2Dead.setPos(Plane2DeadPoint);
            ClassicGameScene.addItem(&Plane2Dead);

            ClassicGameAudio1.play();
            Twins.health -= 50;
            plane2.setX(1250);
            ClassicGameTowerHealthBar->setValue(Twins.health);
        }
        if(BuildingArea.contains(CarArea) && ClassicGameTowerType == 1)
        {
            CarDeadPoint = QPoint(car1.x(),car1.y());
            ClassicGameCarDeadTimer->start(500);
            CarDead.setPixmap(QPixmap(":/images/enemy2_down3.png"));
            CarDead.setPos(CarDeadPoint);
            ClassicGameScene.addItem(&CarDead);

            ClassicGameAudio2.play();
            Twins.health -= 20;
            car1.setX(1200);
            ClassicGameTowerHealthBar->setValue(Twins.health);
        }
        if(BuildingArea.contains(Plane1Area) && ClassicGameTowerType == 2)
        {
            Plane1DeadPoint = QPoint(plane1.x(),plane1.y());
            ClassicGamePlane1DeadTimer->start(500);
            Plane1Dead.setPixmap(QPixmap(":/images/enemy2_down3.png"));
            Plane1Dead.setPos(Plane1DeadPoint);
            ClassicGameScene.addItem(&Plane1Dead);

            ClassicGameAudio1.play();
            Twins.health -= 20;
            plane1.setX(1450);
            ClassicGameTowerHealthBar->setValue(Twins.health);
        }
        if(BuildingArea.contains(Plane2Area) && ClassicGameTowerType == 2)
        {
            Plane2DeadPoint = QPoint(plane2.x(),plane2.y());
            ClassicGamePlane2DeadTimer->start(500);
            Plane2Dead.setPixmap(QPixmap(":/images/enemy2_down3.png"));
            Plane2Dead.setPos(Plane2DeadPoint);
            ClassicGameScene.addItem(&Plane2Dead);

            ClassicGameAudio1.play();
            Twins.health -= 20;
            plane2.setX(1350);
            ClassicGameTowerHealthBar->setValue(Twins.health);
        }
        if(BuildingArea.contains(CarArea) && ClassicGameTowerType == 2)
        {
            CarDeadPoint = QPoint(car1.x(),car1.y());
            ClassicGameCarDeadTimer->start(500);
            CarDead.setPixmap(QPixmap(":/images/enemy2_down3.png"));
            CarDead.setPos(CarDeadPoint);
            ClassicGameScene.addItem(&CarDead);

            ClassicGameAudio2.play();
            Twins.health -= 5;
            car1.setX(1200);
            ClassicGameTowerHealthBar->setValue(Twins.health);
        }
        if(Twins.health <= 0)
        {
            qDebug() << ClassicGameBackgroundTimer->timerId();
            qDebug() << "GameOver";
            ClassicGameTowerHealthBar->setValue(0);
            ClassicGameBackgroundTimer->stop();
            ClassicGamePlane_CarMoveTimer->stop();
            SurviveTimer->stop();
            ClassicGameReloadButton->show();
            ClassicGameStepThreeEnd->setText("Game Over.ur scores:" + QString::number(ClassicGameScore));
            ClassicGameStepThreeEnd->show();
            ClassicGameEndButton->show();

            BgmTimer->stop();
        }
    }
    else if(ClassicGameTowerType >= 3)
    {
        QPoint PlayerPoint = QPoint(Twins.x() + Twins.pixmap().width() / 3,Twins.y() + Twins.pixmap().height()/4);
        QRect SupplyArea = QRect(supply.x(),supply.y(),supply.pixmap().width(),supply.pixmap().height());
        QRect Plane1Area = QRect(plane1.x(),plane1.y(),plane1.pixmap().width()/2,plane1.pixmap().height()/2);
        QRect Plane2Area = QRect(plane2.x(),plane2.y(),plane2.pixmap().width()/2,plane2.pixmap().height()/2);
        QRect CarArea = QRect(car1.x(),car1.y(),car1.pixmap().width()/2,car1.pixmap().height()/2);
        QPoint PlaneStepThreeArea = QPoint(planestep3.x() + planestep3.pixmap().width()/2,planestep3.y()+planestep3.pixmap().height()/4);
        if(Twins.x() > StepTwoBoss.x() || Twins.x() > StepThreeBoss.x())
        {
            Twins.health -= 100;
        }
        if(SupplyArea.contains(PlayerPoint))
        {
            if(Twins.shootspeed - 20 >= 50)
            {
                Twins.shootspeed -= 20;
                ClassicGamePlaneShootTimer->start(Twins.shootspeed);
                qDebug() << "Player ShootSpeed = " << Twins.shootspeed;
            }
            if(Twins.health + 15 <= 100)
            {
                Twins.health += 15;
                ClassicGameTowerHealthBar->setValue(Twins.health);
            }
            supply.setX(2000);
            ++supplyNum;
            supplyPrintLabel->setText(QString::number(supplyNum));

        }
        if(Plane1Area.contains(PlayerPoint) || Plane1Area.contains(PlaneStepThreeArea))
        {
            Plane1DeadPoint = QPoint(plane1.x(),plane1.y());
            ClassicGamePlane1DeadTimer->start(500);
            Plane1Dead.setPixmap(QPixmap(":/images/enemy2_down3.png"));
            Plane1Dead.setPos(Plane1DeadPoint);
            ClassicGameScene.addItem(&Plane1Dead);
            Twins.health -= 80;
            ClassicGameAudio1.play();

            plane1.setX(1450);
            ClassicGameTowerHealthBar->setValue(Twins.health);
        }
        if(Plane2Area.contains(PlayerPoint) || Plane1Area.contains(PlaneStepThreeArea))
        {
            Plane2DeadPoint = QPoint(plane2.x(),plane2.y());
            ClassicGamePlane2DeadTimer->start(500);
            Plane2Dead.setPixmap(QPixmap(":/images/enemy2_down3.png"));
            Plane2Dead.setPos(Plane2DeadPoint);
            ClassicGameScene.addItem(&Plane2Dead);
            Twins.health -= 80;
            ClassicGameAudio1.play();

            plane2.setX(1350);
            ClassicGameTowerHealthBar->setValue(Twins.health);
        }
        if(CarArea.contains(PlayerPoint) || CarArea.contains(PlaneStepThreeArea))
        {
            CarDeadPoint = QPoint(car1.x(),car1.y());
            ClassicGameCarDeadTimer->start(500);
            CarDead.setPixmap(QPixmap(":/images/enemy2_down3.png"));
            CarDead.setPos(CarDeadPoint);
            ClassicGameScene.addItem(&CarDead);

            ClassicGameAudio2.play();
            Twins.health -= 30;
            car1.setX(1200);
            ClassicGameTowerHealthBar->setValue(Twins.health);
        }
        if(Twins.health <= 0)
        {

            qDebug() << ClassicGameBackgroundTimer->timerId();
            qDebug() << "GameOver";
            ClassicGameAudio2.play();
            ClassicGameTowerHealthBar->setValue(0);
            ClassicGameBackgroundTimer->stop();
            ClassicGamePlane_CarMoveTimer->stop();
            SurviveTimer->stop();
            BulletMoveTimer->stop();
            ClassicGamePlaneShootTimer->stop();
            ClassicGameReloadButton->show();
            ClassicGameEndButton->show();
            ClassicGameStepThreeEnd->setText("Game Over.ur scores:" + QString::number(ClassicGameScore));
            ClassicGameStepThreeEnd->show();
            Twins.setPixmap(QPixmap(":/images/enemy2_down3.png"));
            BgmTimer->stop();
            BossMoveTimer->stop();
            BossMoveTimer2->stop();
        }

    }
}
void Widget::ClassicGameReloadButtonClicked()
{
    qDebug() <<"ClassicGameReload";
    KeyList.clear();
    KeyList2.clear();

    Twins.shootspeed = 600;
    Twins.movespeed = 4;
    ClassicGameStepThreeEnd->hide();
    ClassicGameStepPlaneMoveCheck = 0;

    Twins.setPixmap(QPixmap(":/images/TwinTowers.jpg"));
    ClassicGameTowerType = 1;
    ClassicGameReloadButton->hide();
    ClassicGameEndButton->hide();
    ClassicGameScore = 0;
    ClassicGameScorePrint->setText("ur score: " + QString::number(ClassicGameScore));
    ClassicGameStepNum = 1;
    plane1.movespeed = 2.3;
    plane2.movespeed = 2;
    car1.movespeed = 1.6;
    ClassicGameStepPlaneMoveCheck2 = 50;
    Twins.show();
    supplyNum = 0;
    supplyPrintLabel->setText(QString::number(supplyNum));
    plane1.health = 60;
    plane2.health = 60;

    BossMoveCheck1 = 0;
    BossMoveCheck2 = 0;

    StepThreeBoss.setScale(0.6);
    StepThreeBoss.setPos(1200,150);
    StepTwoBoss.setScale(0.5);
    StepTwoBoss.setPos(1200,350);

    car1.setPos(850,578);
    car1.setScale(0.5);
    Twins.setPos(300,320);
    Twins.setScale(0.5);
    plane1.setScale(0.5);
    plane1.setPos(1500,500);
    plane2.setScale(0.5);
    plane2.setPos(700,100);
    plane1type = 1;
    plane2type = 1;
    ClassicGameBackGround1.setPos(0,0);
    ClassicGameBackGround2.setPos(1158,0);
    ClassicGameTowerHealthBar->setValue(100);

    planestep3.setPos(20,280);
    planestep3.hide();
    Twins.health = 100;
    BossMoveTimer->stop();
    ClassicGamePlaneShootTimer->stop();
    ClassicGameBackgroundTimer->start(10);
    ClassicGamePlane_CarMoveTimer->start(1500);
    SurviveTimer->start(2000);
    BulletMoveTimer->stop();
    for(auto bullet : BulletList)
    {
        ClassicGameScene.removeItem(bullet);
        BulletList.removeOne(bullet);
        delete bullet;
    }
    for(auto bullet : BulletList2)
    {
        ClassicGameScene.removeItem(bullet);
        BulletList.removeOne(bullet);
        delete bullet;
    }
    plane1.setPixmap(QPixmap(":/images/plane767.png"));
    plane2.setPixmap(QPixmap(":/images/plane767.png"));
}
void Widget::ClassicGameEndButtonClicked()
{
    qDebug() <<"ClassicGameEnd";
    KeyList.clear();
    KeyList2.clear();

    Twins.shootspeed = 600;
    ClassicGameStepPlaneMoveCheck = 0;

    Twins.setPixmap(QPixmap(":/images/TwinTowers.jpg"));
    ClassicGameTowerType = 1;
    ClassicGameReloadButton->hide();
    ClassicGameEndButton->hide();
    ClassicGameScore = 0;
    ClassicGameScorePrint->setText("ur score: " + QString::number(ClassicGameScore));
    Twins.health = 100;
    ClassicGameTowerHealthBar->setValue(100);
    planestep3.setPos(20,280);
    planestep3.hide();
    ClassicGameStepNum = 1;
    plane1.movespeed = 2.3;
    plane2.movespeed = 2;
    car1.movespeed = 1.6;

    supplyNum = 0;
    supplyPrintLabel->setText(QString::number(supplyNum));

    car1.setPos(850,578);
    car1.setScale(0.5);
    Twins.setPos(300,320);
    Twins.setScale(0.5);
    plane1.setScale(0.5);
    plane1.setPos(1500,500);
    plane2.setScale(0.5);
    plane2.setPos(700,100);
    ClassicGameBackGround1.setPos(0,0);
    ClassicGameBackGround2.setPos(1158,0);
    ClassicGameTowerHealthBar->setValue(100);
    ClassicGameBackgroundTimer->stop();
    ClassicGamePlane_CarMoveTimer->stop();
    ClassicGamePlaneShootTimer->stop();
    GameView.setSceneRect(QRect(0,0,1152,630));
    GameView.setScene(&StartScene);
    BossMoveTimer->stop();
    StartTimer->start(10);
    BulletMoveTimer->stop();
    for(auto bullet : BulletList)
    {
        ClassicGameScene.removeItem(bullet);
        BulletList.removeOne(bullet);
        delete bullet;
    }
    for(auto bullet : BulletList2)
    {
        ClassicGameScene.removeItem(bullet);
        BulletList.removeOne(bullet);
        delete bullet;
    }
    plane1.setPixmap(QPixmap(":/images/plane767.png"));
    plane2.setPixmap(QPixmap(":/images/plane767.png"));

}
Widget::~Widget()
{
    for(auto bullet : BulletList)
    {
        ClassicGameScene.removeItem(bullet);
        BulletList.removeOne(bullet);
        delete bullet;
    }
    for(auto bullet : BulletList2)
    {
        ClassicGameScene.removeItem(bullet);
        BulletList.removeOne(bullet);
        delete bullet;
    }
    delete ui;
}

