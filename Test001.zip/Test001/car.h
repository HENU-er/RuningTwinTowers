#ifndef CAR_H
#define CAR_H
#include <QGraphicsPixmapItem>


class car : public QGraphicsPixmapItem
{

public:
    car(QGraphicsPixmapItem *parent = nullptr);
    double movespeed;
    int health;


};

#endif // CAR_H
